import zipfile
import io
import azure.functions as func
from azure.storage.blob import BlobServiceClient

def main(myblob: func.InputStream):
    blob_service_client = BlobServiceClient.from_connection_string("DefaultEndpointsProtocol=https;AccountName=stgusehmwid1;AccountKey=/uxRX15WBWtznTXpgj1orRRkq3j6ZNH0QFBvA3L1QOl3JWcmj443h0VN7e7RHPo9X03n8gE68gGi+AStHxRY1w==;EndpointSuffix=core.windows.net")
    container_name = "data"
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=myblob.name)
    
    # Download the blob file as a stream
    blob_data = blob_client.download_blob().readall()

    # Unzip the contents
    with zipfile.ZipFile(io.BytesIO(blob_data), 'r') as zip_ref:
        for file_info in zip_ref.infolist():
            file_name = file_info.filename
            extracted_data = zip_ref.read(file_name)
            
            # Upload extracted file back to Blob Storage
            extracted_blob_client = blob_service_client.get_blob_client(container=container_name, blob=file_name)
            extracted_blob_client.upload_blob(extracted_data, overwrite=True)

    print(f"Unzipping completed for {myblob.name}")

