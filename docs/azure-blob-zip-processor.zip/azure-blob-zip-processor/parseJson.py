import json
import logging
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        # Parse request JSON
        req_body = req.get_json()
        resources = req_body.get("resources", [])

        # Extract URLs of the zip files
        zip_urls = [resource.get("path") for resource in resources if resource.get("path").endswith(".zip")]

        # Return the list of URLs as a JSON response
        return func.HttpResponse(
            json.dumps(zip_urls),
            mimetype="application/json",
            status_code=200
        )

    except ValueError:
        return func.HttpResponse(
            "Invalid JSON input.",
            status_code=400
        )
